# FacePlay
Automated spotify player which uses your face to recognize your music

Requirements:

Install openCV2, facerecognition, dlibs, and spotipy using pip.
